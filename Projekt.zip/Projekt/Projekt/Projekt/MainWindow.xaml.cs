﻿using MaterialDesignThemes.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Projekt
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            var menuHome = new List<SubItem>();
            var itemhome = new ItemMenu("Home", menuHome, PackIconKind.Home);

            var menuKaja = new List<SubItem>();
            menuKaja.Add(new SubItem("Pizza"));
            menuKaja.Add(new SubItem("Hotdog"));
            menuKaja.Add(new SubItem("Hamburger"));
            menuKaja.Add(new SubItem("Taco"));
            menuKaja.Add(new SubItem("Tortilla"));
            var item0 = new ItemMenu("Étel", menuKaja, PackIconKind.Car);

            
            var menuItal = new List<SubItem>();
            menuItal.Add(new SubItem("Szénsavas"));
            menuItal.Add(new SubItem("Szénsavmentes"));
            menuItal.Add(new SubItem("Rostos"));
            menuItal.Add(new SubItem("Szeszes"));
            var item1 = new ItemMenu("Ital", menuItal, PackIconKind.Drink);



            Menu.Children.Add(new UserControlMenuItem(itemhome));
            Menu.Children.Add(new UserControlMenuItem(item0));
            Menu.Children.Add(new UserControlMenuItem(item1));

        }
        private void LoadPictures()
        {

        }

        private void btLogin_Click(object sender, RoutedEventArgs e)
        {
            Login LoginWindow = new Login();
            LoginWindow.Show();
        }

        private void btExit_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }
    }
}
